
.. automodule:: adafruit_bno055
   :members:
