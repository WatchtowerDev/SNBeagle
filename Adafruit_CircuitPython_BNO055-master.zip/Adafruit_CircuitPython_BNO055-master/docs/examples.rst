Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/bno055_simpletest.py
    :caption: examples/bno055_simpletest.py
    :linenos:
