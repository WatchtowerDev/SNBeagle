.. ref-fps

===
fps
===

boto.fps
--------

.. automodule:: boto.fps
   :members:   
   :undoc-members:

boto.fps.connection
-------------------

.. automodule:: boto.fps.connection
   :members:   
   :undoc-members:
