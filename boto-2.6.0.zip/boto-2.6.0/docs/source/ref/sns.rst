.. ref-sns

===
SNS
===

boto.sns
--------

.. automodule:: boto.sns
   :members:   
   :undoc-members:

.. autoclass:: boto.sns.SNSConnection
   :members:
   :undoc-members:

