# __init__.py file for PyBBIO's ADS786x library

from ads786x import ADS7866, ADS7867, ADS7868
