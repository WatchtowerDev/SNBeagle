eQEP - v0.1

Copyright 2014 Rekha Seethamraju
rekha.kmit@gmail.com

Library for controlling rotary encoder with the Beaglebone Black's eQEP pins.

See documentation here:  
https://github.com/alexanderhiam/PyBBIO/wiki/eQEP  
As well as the included example programs:  
https://github.com/alexanderhiam/PyBBIO/examples/encoder_test.py

eQEP is released as part of PyBBIO under its MIT license.  
See PyBBIO/LICENSE.txt
