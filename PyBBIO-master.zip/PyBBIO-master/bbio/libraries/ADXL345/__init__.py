# __init__.py file for PyBBIO's ADXL345 library
from ADXL345 import ADXL345
